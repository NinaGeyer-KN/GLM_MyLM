#install.packages("car")
library(car)

data(SLID, package = "carData")
SLID <- SLID[complete.cases(SLID), ]

#base
mylm_base = mylm(wages ~ education, data=SLID)

#test 4.a
mylm_4a = mylm(wages ~ sex + age + language + I(education^2), data=SLID)

#test 4.b
mylm_4b = mylm(wages ~ language + age + language:age, data=SLID)

#test 4.c
mylm_4c = mylm(wages ~ 0 + education, data=SLID)
